# Splunk-Modal-Window

Example Splunk app allowing you to add searches to a modal window in your Splunk dashboard.
